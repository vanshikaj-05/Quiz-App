package com.example.quizapp;

public class QuestionAnswer {
    public static String question [] ={
        "what is 10+26 ?",
            "Who invented Telephone ?",
            "what is 12+9 ?",
            "who is the founder of SpaceX ?",
            "In the given options,which is the Example of System Software ?"
    };

    public static String choices [][] = {
            {"32","42","36","38"},
            {"Graham Bell","Einstein","Edison","None of the above"},
            {"96","84","102","108"},
            {"Jeff Bezoz","Elon Musk","Steve Jobs","Bill Gates"},
            {"Windows","Linux","MacOS" ,"All of the above"},
    };

    public static String correctAnswer []={
            "36",
            "Graham Bell",
            "108",
            "Elon Musk",
            "All of the above",
    };
}
